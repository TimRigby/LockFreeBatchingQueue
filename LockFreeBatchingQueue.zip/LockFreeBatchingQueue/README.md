# LockFreeBatchingQueue
README

To compile the Batching Queue
	javac LFQueue.java
To run
	java LFQueue

To edit the number of threads running on the queue, alter the THREAD_NUMBER field to specify the number to run. To edit the number of operations performed, alter the while condition within the run() method
